var jQ = jQuery.noConflict();
jQ(document).ready(function()
{
        // jQ('.sort_grid').panelGroup('table1');
        //         jQ('.sort_column').panelGroup('table2');
        //         jQ('.sort_row').panelGroup('table3');
        jQ('.sort_row').panelGroup();
        jQ('.mod').editText();
});
