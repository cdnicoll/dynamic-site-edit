var jQ = jQuery.noConflict();
jQ(document).ready(function()
{
    jQ('.mod').editText();
    
});
